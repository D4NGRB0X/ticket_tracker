default_endpoint: str = "https://api.clockify.me/api/v1/"
api_key: str = "YOUR API KEY GOES HERE"
header = {"X-Api-Key": api_key, "content-type": "application/json"}
